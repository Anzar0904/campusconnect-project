import React, { memo } from 'react';

interface GlobalAvatarProps {
  src?: string;
  name?: string;
  username?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  status?: 'online' | 'offline' | 'typing';
}

export const GlobalAvatar: React.FC<GlobalAvatarProps> = memo(({
  src,
  name,
  username,
  size = 'md',
  className = '',
  status,
}) => {
  const getInitial = () => {
    if (name) return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    if (username) return username.charAt(0).toUpperCase();
    return 'U';
  };

  const sizeClasses = {
    xs: 'w-6 h-6 text-[9px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
    xl: 'w-16 h-16 text-lg',
  };

  return (
    <div className={`relative inline-block flex-shrink-0 select-none ${className}`}>
      {src ? (
        <img
          src={src}
          alt={name || 'User Profile avatar'}
          className={`${sizeClasses[size]} rounded-full object-cover ring-1 ring-white/10`}
          loading="lazy"
        />
      ) : (
        <div className={`${sizeClasses[size]} rounded-full bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-600 text-white font-bold tracking-tight flex items-center justify-center ring-1 ring-white/10`}>
          {getInitial()}
        </div>
      )}
      {status && (
        <span className={`absolute bottom-0 right-0 block rounded-full ring-1.5 ring-[#030712] ${
          status === 'online' ? 'bg-emerald-400 neon-ring-active w-2.5 h-2.5' :
          status === 'typing' ? 'bg-sky-400 w-2.5 h-2.5 animate-pulse' : 'bg-neutral-500 w-2.5 h-2.5'
        }`} />
      )}
    </div>
  );
});

GlobalAvatar.displayName = 'GlobalAvatar';
